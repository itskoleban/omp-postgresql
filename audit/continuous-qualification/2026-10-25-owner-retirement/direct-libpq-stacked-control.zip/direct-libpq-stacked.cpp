#include <libpq-fe.h>
#include <chrono>
#include <iostream>
#include <string>
#include <thread>
int main(int argc, char **argv) {
  if(argc<2) return 64;
  PGconn *c=PQconnectdb(argv[1]);
  std::cout << "libpq=" << PQlibVersion() << " connect_status=" << PQstatus(c)
            << " server=" << PQserverVersion(c) << " backend=" << PQbackendPID(c)
            << " tls=" << PQsslInUse(c) << std::endl;
  if(PQstatus(c)!=CONNECTION_OK) { std::cerr << PQerrorMessage(c); PQfinish(c); return 1; }
  PGresult *r=PQexecParams(c,"SELECT 1",0,nullptr,nullptr,nullptr,nullptr,0);
  bool valid=r && PQresultStatus(r)==PGRES_TUPLES_OK && std::string(PQgetvalue(r,0,0))=="1";
  std::cout << "valid_select=" << valid << std::endl;
  PQclear(r);
  if(!valid) { PQfinish(c); return 1; }
  if(argc>2) { PQfinish(c); return 0; }
  PQsetnonblocking(c,1);
  const auto start=std::chrono::steady_clock::now();
  std::cout << "stacked_send=" << PQsendQueryParams(c,"SELECT 1; SELECT 2",0,nullptr,nullptr,nullptr,nullptr,0)
            << " expected_sqlstate=42601" << std::endl;
  bool got=false;
  const auto deadline=start+std::chrono::milliseconds(2000);
  while(std::chrono::steady_clock::now()<deadline) {
    if(PQflush(c)<0 || !PQconsumeInput(c)) { std::cerr << "transport_error=" << PQerrorMessage(c); break; }
    if(!PQisBusy(c)) {
      r=PQgetResult(c);
      if(!r) break;
      const char *state=PQresultErrorField(r,PG_DIAG_SQLSTATE);
      std::cout << "result_status=" << PQresultStatus(r) << " sqlstate=" << (state?state:"")
                << " message=" << PQresultErrorMessage(r) << std::endl;
      got=state && std::string(state)=="42601";
      PQclear(r);
    }
    std::this_thread::sleep_for(std::chrono::milliseconds(1));
  }
  std::cout << "stacked_expected_response=" << got << " elapsed_ms="
            << std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now()-start).count()
            << " connection_status=" << PQstatus(c) << std::endl;
  PQfinish(c);
  return got?0:2;
}
