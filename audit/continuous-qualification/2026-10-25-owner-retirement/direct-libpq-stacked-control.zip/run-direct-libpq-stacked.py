import csv, hashlib, json, os, pathlib, re, shutil, socket, subprocess, tempfile, time
base=pathlib.Path(__file__).resolve().parent
root=pathlib.Path(tempfile.mkdtemp(prefix='direct-libpq-stacked-',dir=base))
pg=pathlib.Path('C:/msys64/ucrt64/bin')
env=dict(os.environ,PATH=str(pg)+os.pathsep+os.environ['PATH'])
flags=subprocess.CREATE_NO_WINDOW
identity=subprocess.check_output(['whoami','/user','/fo','csv','/nh'],creationflags=flags).decode('ascii',errors='replace')
sid=next(csv.reader(identity.splitlines()))[1]
assert re.fullmatch(r'S-\d+(?:-\d+)+',sid)
def run(name,argv,timeout=30,check=True):
    with (root/name).open('wb') as f:
        result=subprocess.run([str(x) for x in argv],env=env,stdout=f,stderr=subprocess.STDOUT,creationflags=flags,timeout=timeout)
    print(name,result.returncode,flush=True)
    if check: result.check_returncode()
    return result.returncode
run('acl.log',['icacls',root,'/grant',f'*{sid}:(OI)(CI)F'])
data=root/'data'
run('initdb.log',[pg/'initdb.exe','-D',data,'-U','omp_test','-A','trust','--encoding=UTF8','--no-locale'])
with socket.socket() as s:
    s.bind(('127.0.0.1',0)); port=s.getsockname()[1]
old=base/'omp-pg-integration-v76mxio9/data'
for n in ('server.crt','server.key'): shutil.copy2(old/n,data/n)
with (data/'postgresql.conf').open('a') as f:
    f.write(f"\nlisten_addresses='127.0.0.1'\nport={port}\nunix_socket_directories=''\nssl=on\nlog_timezone='UTC'\nlog_statement='all'\nlog_connections=on\nlog_disconnections=on\n")
conn=f"host=localhost hostaddr=127.0.0.1 port={port} dbname=postgres user=omp_test sslmode=verify-full sslrootcert='{(data/'server.crt').as_posix()}' connect_timeout=3"
metadata={'root':str(root),'postgres_sha256':hashlib.sha256((pg/'postgres.exe').read_bytes()).hexdigest(),'libpq_sha256':hashlib.sha256((pg/'libpq.dll').read_bytes()).hexdigest(),'control_source_sha256':hashlib.sha256((base/'direct-libpq-stacked.cpp').read_bytes()).hexdigest(),'control_binary_sha256':hashlib.sha256((base/'direct-libpq-stacked.exe').read_bytes()).hexdigest()}
metadata['postgres_version']=subprocess.check_output([str(pg/'postgres.exe'),'--version'],env=env,creationflags=flags).decode().strip()
(root/'manifest.json').write_text(json.dumps(metadata,indent=2))
shutil.copy2(base/'direct-libpq-stacked.cpp',root/'direct-libpq-stacked.cpp')
try:
    run('start.log',[pg/'pg_ctl.exe','-D',data,'-l',root/'server.log','-w','start'])
    metadata['stacked_exit']=run('stacked.log',[base/'direct-libpq-stacked.exe',conn],timeout=10,check=False)
    time.sleep(6)
    metadata['fresh_select_exit']=run('fresh-select.log',[base/'direct-libpq-stacked.exe',conn,'--select-only'],timeout=10,check=False)
finally:
    metadata['stop_exit']=run('stop.log',[pg/'pg_ctl.exe','-D',data,'-m','immediate','-w','stop'],check=False)
    (root/'manifest.json').write_text(json.dumps(metadata,indent=2))
print(root,flush=True)
print((root/'stacked.log').read_text(errors='replace'),flush=True)
print((root/'fresh-select.log').read_text(errors='replace'),flush=True)
