"""Bounded local allocation regression using the repository's TLS fixture setup."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

parser = argparse.ArgumentParser()
parser.add_argument("--label", required=True)
parser.add_argument("--binary", required=True)
parser.add_argument("arguments", nargs="*")
options = parser.parse_args()
work = Path(__file__).resolve().parent
repo = work / "omp-postgresql"
sys.path.insert(0, str(repo / "tests"))
tempfile.tempdir = str(work)
source = (repo / "tests/run_postgres.py").read_text(encoding="utf8")
prefix = source.split('restart_request = root / "restart-request"')[0]
sys.argv = [str(repo / "tests/run_postgres.py"), "--build", str(work / "build-core")]
namespace = {"__file__": str(repo / "tests/run_postgres.py"), "__name__": "local_fixture"}
exec(compile(prefix, namespace["__file__"], "exec"), namespace)
run, root, data, env = (namespace[x] for x in ("run", "root", "data", "env"))
output = work / options.label
output.mkdir(exist_ok=False)
result = None
try:
    run(["pg_ctl", "-D", str(data), "-l", str(root / "server.log"), "-w", "start"])
    command = [str(Path(options.binary).resolve()), *options.arguments]
    with (output / "test-output.txt").open("wb") as capture:
        result = subprocess.run(command, env=env, stdout=capture, stderr=subprocess.STDOUT,
                                timeout=90, creationflags=subprocess.CREATE_NO_WINDOW)
    print((output / "test-output.txt").read_text(encoding="utf8", errors="replace"))
finally:
    run(["pg_ctl", "-D", str(data), "-m", "immediate", "-w", "stop"])
    stopped = not (data / "postmaster.pid").exists()
    import shutil
    for log in root.glob("*.log"):
        shutil.copyfile(log, output / log.name)
    (output / "observation.json").write_text(json.dumps({
        "fixture": str(root), "command": command,
        "returncode": None if result is None else result.returncode,
        "server_stopped_pid_absent": stopped,
        "source_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip(),
        "source_worktree_diff": subprocess.check_output(["git", "diff", "--", "src/session.cpp"], cwd=repo, text=True),
    }, indent=2) + "\n", encoding="utf8")
sys.exit(result.returncode if result else 1)
